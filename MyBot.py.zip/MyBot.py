from hlt import *
from networking import *

myID, gameMap = getInit()
sendInit("aranair")

xs = { 1: 0, 2: 1, 3: 0, 4: -1 }
ys = { 1: -1, 2: 0, 3: 1, 4: 0 }

def findNearestBorderDirection(gameMap, x, y):
    return;

def findGreatestProductionDirection(gameMap, x, y):
    maxProduction = 0
    direction = False
    for d in CARDINALS:
        newSite = gameMap.getSite(Location(x, y), d)
        # new site is weaker
        if newSite.owner != myID and newSite.strength < gameMap.getSite(Location(x, y)).strength and newSite.production > maxProduction:
            maxProduction = newSite.production
            direction = d

    return direction;


while True:
    moves = []
    gameMap = getFrame()
    for y in range(gameMap.height):
        for x in range(gameMap.width):
            if gameMap.getSite(Location(x, y)).owner == myID:
                movedPiece = False

                newDirection = findGreatestProductionDirection(gameMap, x, y)
                if newDirection:
                    moves.append(Move(Location(x, y), newDirection))
                    movedPiece = True
                    break

                # if not movedPiece:
                #     for d in CARDINALS:
                #         newX = x + xs[d]
                #         newY = y + ys[d]
                #         count = 0
                #         for d2 in CARDINALS:
                #             if gameMap.getSite(Location(newX, newY), d2).owner != myID:
                #                 count = count + 1

                #         if count > 3:
                #             moves.append(Move(Location(x, y), d))
                #             movedPiece = True
                #             break

                if not movedPiece and gameMap.getSite(Location(x, y)).strength < gameMap.getSite(Location(x, y)).production * 8:
                    moves.append(Move(Location(x, y), STILL))
                    movedPiece = True

                if not movedPiece:
                    # moves.append(Move(Location(x, y), NORTH if bool(int(random.random() * 2)) else WEST))
                    moves.append(Move(Location(x, y), random.choice([1,2,3,4])))
                    movedPiece = True
    sendFrame(moves)
